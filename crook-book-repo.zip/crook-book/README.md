# The Crook Book

A planner in a single HTML file. No install, no server, no accounts. Open `index.html` in Chrome or Edge and it works.

Built for people who think faster than they file: catch a thought in one click, get reminded properly, and never lose a note.

## What it does

- Quick capture with one button or the **N** key, by typing or by voice
- Reminders with a heads-up, a loud alert, and repeat nudges until you act
- Meeting mode that files everything you capture under the meeting, with a recap to copy
- Checklists with tick boxes and a progress bar
- Dictation that tidies spelling, capital letters and punctuation, then leaves it for you to read before saving
- A focus card, a Top 3 for the day, a day bar, and plan-my-day and wrap-up prompts
- 1-2-1 prep that gathers questions, wins and anything you're stuck on
- Eight themes, text size and font options, bigger buttons, a simple view and keyboard shortcuts
- Saves to a folder you choose, with a daily backup
- Optional sharing through a Google Drive folder so two people can work on chosen items together

## Quick start

1. Download `index.html` and keep it somewhere permanent, such as Documents
2. Open it in Chrome or Edge
3. Press **Choose my folder** and pick a new folder, for example one called The Crook Book inside Documents
4. Pin the browser tab. Alerts only fire while the page is open

Chrome and Edge won't let you pick Documents or Desktop itself, so make a new folder inside first.

## Working together through Google Drive

Only items you mark **Shared** go into the shared folder. Everything else stays private.

1. Make a folder in Google Drive that both people can edit. A folder inside a Shared drive is easiest
2. Check it appears in File Explorer under Google Drive (needs Google Drive for desktop)
3. Each person opens the app, then in **Settings** sets their own name and the other person's name, spelled the same way each time
4. Each person presses **Choose the shared folder** and picks that folder
5. Tick **Shared** on anything the other person should see, or use **For [name]** to put something on their list

How it works: each person writes their own file (`crook-shared-<name>.json`) into the folder and reads the other's, so two people never edit the same file at once. Items are merged by last change, comments are always kept, and deletes are tracked so nothing comes back.

## Where your data lives

- In the browser, as a working copy
- In your save folder: `crook-book.json`, a `backups` folder with one copy a day (newest 30 kept) and a `meetings` folder with a recap of each meeting
- In the shared folder, only shared items

No data is sent anywhere else. Voice typing uses the browser's own speech service, which sends audio to the browser vendor.

## Updating your copy

Your data is not stored in `index.html`, so replacing the file is safe.

1. Replace the old `index.html` with the new one, in the same place
2. Open it. If the planner looks empty, press **Choose my folder** and pick your existing folder. Everything loads back

## Making changes

Everything is in `index.html`: styles at the top, then the markup, then one script. There is no build step.

- Edit the file, open it in Chrome, and click through the screen you changed
- Check the script parses: copy the contents of the `<script>` tag into a file and run `node --check file.js`
- Work on a branch and open a pull request. Don't commit straight to `main`
- Settings that affect saved data (new fields on items, for example) need a default in `DEF()` and, if old data must be upgraded, a line in `migrate()`

## Known limits

- Chrome and Edge on a computer only, because folder saving needs the File System Access API
- Alerts need the tab open, and background tabs can be up to a minute late
- Dictation depends on the browser's speech service and microphone permission. If it fails the app says why, and Windows dictation (Windows key + H) works in any box
- The spelling and grammar tidy-up is a quick rule-based pass, not a full grammar checker, so the review step matters
- Tested with scripted simulations. Real-browser testing with Google Drive sharing is still to do
